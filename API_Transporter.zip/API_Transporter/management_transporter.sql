-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 20, 2023 at 06:34 AM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 7.4.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `management_transporter`
--

-- --------------------------------------------------------

--
-- Table structure for table `barang`
--

CREATE TABLE `barang` (
  `id` int(11) NOT NULL,
  `kode_barang` varchar(10) NOT NULL,
  `nama_barang` varchar(200) DEFAULT NULL,
  `deskripsi` text DEFAULT NULL,
  `stok_barang` int(11) DEFAULT NULL,
  `harga_barang` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `barang`
--

INSERT INTO `barang` (`id`, `kode_barang`, `nama_barang`, `deskripsi`, `stok_barang`, `harga_barang`) VALUES
(1, '411', 'Aston Martin Valkriye', 'F1 Edition', 1, 3000000);

-- --------------------------------------------------------

--
-- Table structure for table `kurir`
--

CREATE TABLE `kurir` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `kurir`
--

INSERT INTO `kurir` (`id`, `name`, `email`, `password`) VALUES
(1, 'Tyas Dwi Angga', '411201063@mahasiswa.undira.ac.id', '$2y$10$O.Y3Su8DKYQMYmVh.lHtOubhYw6lLaapVs/5l870l4MDCBlZWajXO'),
(2, 'Jankov.', 'jenkins1@gmail.com', '$2y$10$lSrgqmyLedYIOcnKbKAPvOZGXIKqjlj.NfaTD3Se4EL043wGnixNq');

-- --------------------------------------------------------

--
-- Table structure for table `lokasi`
--

CREATE TABLE `lokasi` (
  `id` int(11) NOT NULL,
  `kode_lokasi` varchar(10) DEFAULT NULL,
  `nama_lokasi` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `lokasi`
--

INSERT INTO `lokasi` (`id`, `kode_lokasi`, `nama_lokasi`) VALUES
(1, '411', 'Alexandria'),
(2, '1', 'Jakarta'),
(3, '421', 'Stockholm');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(7, '2019_12_14_000001_create_personal_access_tokens_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `pengiriman`
--

CREATE TABLE `pengiriman` (
  `id` int(11) NOT NULL,
  `no_pengiriman` varchar(15) NOT NULL,
  `tanggal` date NOT NULL,
  `lokasi_id` int(11) DEFAULT NULL,
  `barang_id` int(11) DEFAULT NULL,
  `jumlah_barang` int(11) NOT NULL,
  `harga_barang` int(11) DEFAULT NULL,
  `kurir_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pengiriman`
--

INSERT INTO `pengiriman` (`id`, `no_pengiriman`, `tanggal`, `lokasi_id`, `barang_id`, `jumlah_barang`, `harga_barang`, `kurir_id`) VALUES
(1, '242', '2023-05-16', 411, 411, 3000000, 1, 2);

-- --------------------------------------------------------

--
-- Table structure for table `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `personal_access_tokens`
--

INSERT INTO `personal_access_tokens` (`id`, `tokenable_type`, `tokenable_id`, `name`, `token`, `abilities`, `last_used_at`, `created_at`, `updated_at`) VALUES
(1, 'App\\Models\\Kurir', 1, 'api-token', '7a512777505e867f740fd51a433e5331e6dea61941edf8c02fded8fb3b71727c', '[\"*\"]', NULL, '2023-05-19 01:41:03', '2023-05-19 01:41:03'),
(2, 'App\\Models\\Kurir', 1, 'api-token', 'bb65dcda0ad39f5be4a49bfb5d8c078009f82c4e10dcbe5f26091796e6d22377', '[\"*\"]', NULL, '2023-05-19 02:16:56', '2023-05-19 02:16:56'),
(3, 'App\\Models\\Kurir', 1, 'api-token', 'fffc2160b43d4077a7d6af383e9c20b2f1b7ad27d865bde2013e411357e329ca', '[\"*\"]', NULL, '2023-05-19 02:17:03', '2023-05-19 02:17:03'),
(4, 'App\\Models\\Kurir', 1, 'api-token', '87c84c125b2207358f03a972516cc770442075075f201db5ae1bcaa48ad3fdc2', '[\"*\"]', NULL, '2023-05-19 02:17:44', '2023-05-19 02:17:44'),
(5, 'App\\Models\\Kurir', 1, 'api-token', '18ac8a2f534d88a7b26a0fd1cdb2d6d4d6bac8fbaeee96ca2c455bcb680b5dd7', '[\"*\"]', NULL, '2023-05-19 02:17:50', '2023-05-19 02:17:50'),
(6, 'App\\Models\\Kurir', 1, 'api-token', 'ecbab312ed88b17b335330da20c98ea1c42d6e589bddd30a0915cd90e8c23261', '[\"*\"]', NULL, '2023-05-19 02:18:19', '2023-05-19 02:18:19'),
(7, 'App\\Models\\Kurir', 1, 'api-token', 'b0757cfef5439063118fc7a7f609cc7b070c66ee35ee2614cd1edf98e9088676', '[\"*\"]', NULL, '2023-05-19 02:18:31', '2023-05-19 02:18:31'),
(8, 'App\\Models\\Kurir', 1, 'api-token', '227ea69f0ef1c1ea2aecf1e547c93d80ee39640e81292678ee4e292438a9cd12', '[\"*\"]', NULL, '2023-05-19 02:19:38', '2023-05-19 02:19:38'),
(9, 'App\\Models\\Kurir', 1, 'api-token', '678bf50ae79b726368e8502af3669916f7de6180981a93e8dda0bc550919e0fd', '[\"*\"]', NULL, '2023-05-19 20:48:00', '2023-05-19 20:48:00'),
(10, 'App\\Models\\Kurir', 1, 'api-token', '66cba1256932ce37dc9e452b1eafb15c68b6a8a29c57995077559f8871c9bbde', '[\"*\"]', NULL, '2023-05-19 20:48:47', '2023-05-19 20:48:47'),
(11, 'App\\Models\\Kurir', 1, 'api-token', '511bfb6c97c86d20c3a660de42f34517b803be9f78a57ac538e317dab4ed6385', '[\"*\"]', NULL, '2023-05-19 21:03:37', '2023-05-19 21:03:37'),
(12, 'App\\Models\\Kurir', 1, 'api-token', '09da68cff4e21eb18c5f53ee7fc29541fd10caea101d9d04d3e0c36eeb03b83c', '[\"*\"]', NULL, '2023-05-19 21:05:47', '2023-05-19 21:05:47'),
(13, 'App\\Models\\Kurir', 1, 'api-token', '9e3fea758cec59b807d085ed897ba98ed32ef460235d6b1e062663c0f4fd6080', '[\"*\"]', NULL, '2023-05-19 21:08:20', '2023-05-19 21:08:20'),
(14, 'App\\Models\\Kurir', 1, 'api-token', 'ce32f368e2ac68a354bb071939cbf79c902af68a3ed2c040d853bbaaea517efc', '[\"*\"]', NULL, '2023-05-19 21:08:59', '2023-05-19 21:08:59'),
(15, 'App\\Models\\Kurir', 1, 'api-token', '18a3ca0a3d97228243f4995925681d18a82cd4b54facb68a61fab62df9f42097', '[\"*\"]', NULL, '2023-05-19 21:12:10', '2023-05-19 21:12:10'),
(16, 'App\\Models\\Kurir', 1, 'api-token', 'a2b9b1c6a5265890bd7ddbdb28781a16138e7e9b345d871bfc1ff323ce4052ba', '[\"*\"]', NULL, '2023-05-19 21:17:43', '2023-05-19 21:17:43'),
(17, 'App\\Models\\Kurir', 1, 'api-token', 'a68f1d7a9a939851529e4873f678eae39880a323b4dd5a28ecf839df88ddd19a', '[\"*\"]', NULL, '2023-05-19 21:20:41', '2023-05-19 21:20:41');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `barang`
--
ALTER TABLE `barang`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `kurir`
--
ALTER TABLE `kurir`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `lokasi`
--
ALTER TABLE `lokasi`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pengiriman`
--
ALTER TABLE `pengiriman`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `barang`
--
ALTER TABLE `barang`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `kurir`
--
ALTER TABLE `kurir`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `lokasi`
--
ALTER TABLE `lokasi`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `pengiriman`
--
ALTER TABLE `pengiriman`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
