<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\Kurir;
use App\Models\Barang;
use App\Models\Lokasi;
use App\Models\Pengiriman;

class getDataPackage extends Controller
{

    public function getDataMaster()
    {
        $kurirs = Kurir::all();
        $barangs = Barang::all();
        $lokasis = Lokasi::all();

        return response()->json([
            'kurirs' => $kurirs,
            'barangs' => $barangs,
            'lokasis' => $lokasis,
        ], 200);
    }
}