<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\Pengiriman;

class PengirimanPackage extends Controller
{   
	public function createPengiriman(Request $request)
    {
				
        $request->validate([
            'no_pengiriman' => 'required',
            'tanggal' => 'required|date',
            'lokasi_id' => 'required|exists:lokasis,id',
            'barang_id' => 'required|exists:barangs,id',
            'jumlah_barang' => 'required|integer',
            'harga_barang' => 'nullable|integer',
            'kurir_id' => 'nullable|exists:kurirs,id',
        ]);

        $pengiriman = Pengiriman::create([
            'no_pengiriman' => $request->no_pengiriman,
            'tanggal' => $request->tanggal,
            'lokasi_id' => $request->lokasi_id,
            'barang_id' => $request->barang_id,
            'jumlah_barang' => $request->jumlah_barang,
            'harga_barang' => $request->harga_barang,
            'kurir_id' => $request->kurir_id,
        ]);

        return response()->json(['message' => 'Pengiriman created successfully', 'data' => $pengiriman], 201);
    }