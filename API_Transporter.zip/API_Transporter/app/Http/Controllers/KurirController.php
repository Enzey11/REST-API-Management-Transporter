<?php

namespace App\Http\Controllers;

use App\Models\Kurir;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\ValidationException;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Session;

class KurirController extends Controller
{
    public function index()
    {
			$kurirId = Session::get('kurir_id');
			echo session()->get('user_name');

        $kurirs = Kurir::all();

        return response()->json($kurirs, 200);
    }

    public function store(Request $request)
    {
				$validator = Validator::make($request->all(), [
								'name' => 'required',
								'email' => 'required|email|unique:kurir,email' ,
								'password' => 'required',
				]);

				if ($validator->fails()) {
						return response()->json(['errors' => $validator->errors()], 422);
				}
        $kurir = Kurir::create([
            'name' => $request->name,
            'email' => $request->email,
            'password' => Hash::make($request->password),
        ]);

        return response()->json($kurir, 201);
    }

    public function show($id)
    {
        $kurir = Kurir::find($id);

        if (!$kurir) {
            return response()->json(['message' => 'Kurir not found'], 404);
        }

        return response()->json($kurir, 200);
    }

    public function update(Request $request, $id)
    {
        $kurir = Kurir::find($id);

        if (!$kurir) {
            return response()->json(['message' => 'Kurir not found'], 400);
        }

				$validator = Validator::make($request->all(), [
								'name' => 'required',
								'email' => 'required|email|unique:kurir,email',
								'password' => 'required',
				]);

				if ($validator->fails()) {
						return response()->json(['errors' => $validator->errors()], 422);
				}

        $kurir->update([
            'name' => $request->name,
            'email' => $request->email,
            'password' => Hash::make($request->password),
        ]);
				$kurir['success'] = 'name,email,pass, has been updated';
        return response()->json($kurir, 200);
    }

    public function destroy($id)
    {
        $kurir = Kurir::find($id);

        if (!$kurir) {
            return response()->json(['message' => 'Kurir not found'], 404);
        }

        $kurir->delete();

        return response()->json(['message' => 'Kurir deleted successfully'], 200);
    }
}
