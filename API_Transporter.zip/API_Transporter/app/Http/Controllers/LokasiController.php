<?php

namespace App\Http\Controllers;

use App\Models\Lokasi;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Validation\ValidationException;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\Validator;

class LokasiController extends Controller
{
    public function index()
    {
        $lokasis = Lokasi::all();

        return response()->json($lokasis, 200);
    }

    public function store(Request $request)
    {

				$validator = Validator::make($request->all(), [
						'kode_lokasi' => 'required|unique:lokasi,kode_lokasi,' ,
						'nama_lokasi' => 'required',
				]);

				if ($validator->fails()) {
						return response()->json(['errors' => $validator->errors()], 422);
				}
				$lokasi = Lokasi::create([
						'kode_lokasi' => $request->kode_lokasi,
						'nama_lokasi' => $request->nama_lokasi,
				]);

				return response()->json($lokasi, 201);
    }

    public function show($id)
    {
        $lokasi = Lokasi::find($id);

        if (!$lokasi) {
            return response()->json(['message' => 'Lokasi not found'], 400);
        }

        return response()->json($lokasi, 200);
    }

    public function update(Request $request, $id)
    {
        $lokasi = Lokasi::find($id);

        if (!$lokasi) {
            return response()->json(['message' => 'Lokasi not found'], 400);
        }
    $validator = Validator::make($request->all(), [
        'kode_lokasi' => 'required|unique:lokasi,kode_lokasi,' . $lokasi->id,
        'nama_lokasi' => 'required',
    ]);

    if ($validator->fails()) {
        return response()->json(['errors' => $validator->errors()], 422);
    }

        $lokasi->update([
            'kode_lokasi' => $request->kode_lokasi,
            'nama_lokasi' => $request->nama_lokasi,
        ]);
			$lokasi['success'] = 'kode & nama lokasi has been updated';
        return response()->json($lokasi, 200);
    }

    public function destroy($id)
    {
        $lokasi = Lokasi::find($id);
			if (!$lokasi) {
            return response()->json(['message' => 'Lokasi not found'], 404);
        }

        $lokasi->delete();

        return response()->json(['message' => 'Lokasi deleted successfully'], 200);
    }
}
