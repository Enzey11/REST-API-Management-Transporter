<?php

namespace App\Http\Controllers;

use App\Models\Barang;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Validation\ValidationException;
use Illuminate\Support\Facades\Validator;

class BarangController extends Controller
{
    public function index()
    {
        $barangs = Barang::all();

        return response()->json($barangs, 200);
    }

    public function store(Request $request)
    {

				$validator = Validator::make($request->all(), [
            'kode_barang' => 'required|unique:barang,kode_barang',
            'nama_barang' => 'required',
            'deskripsi' => 'required',
            'stok_barang' => 'required|integer',
            'harga_barang' => 'required|numeric',
				]);

				if ($validator->fails()) {
						return response()->json(['errors' => $validator->errors()], 422);
				}
        $barang = Barang::create($request->all());

        return response()->json($barang, 201);
    }

    public function show($id)
    {
        $barang = Barang::find($id);

        if (!$barang) {
            return response()->json(['message' => 'Barang not found'], 404);
        }

        return response()->json($barang, 200);
    }

    public function update(Request $request, $id)
    {
        $barang = Barang::find($id);

        if (!$barang) {
            return response()->json(['message' => 'Barang not found'], 404);
        }

       	$validator = Validator::make($request->all(), [
            'kode_barang' => 'required|unique:barang,kode_barang',
            'nama_barang' => 'required',
            'deskripsi' => 'required',
            'stok_barang' => 'required|integer',
            'harga_barang' => 'required|numeric',
				]);

				if ($validator->fails()) {
						return response()->json(['errors' => $validator->errors()], 422);
				}

        $barang->update($request->all());

        return response()->json($barang, 200);
    }

    public function destroy($id)
    {
        $barang = Barang::find($id);

        if (!$barang) {
            return response()->json(['message' => 'Barang not found'], 404);
        }

        $barang->delete();

        return response()->json(['message' => 'Barang deleted successfully'], 200);
    }
}
