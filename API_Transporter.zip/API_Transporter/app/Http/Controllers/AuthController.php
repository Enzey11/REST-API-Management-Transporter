<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Http\Controllers\Controller;
use App\Models\Kurir;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Validation\ValidationException;
use Illuminate\Support\Facades\Session;

class AuthController extends Controller
{
    public function login(Request $request)
    {
        $credentials = $request->only('email', 'password');

        if (Auth::attempt(['email' => $credentials['email'], 'password' => $credentials['password']])) {
            $user = Auth::user();
            $token = $user->createToken('api-token')->plainTextToken;
						session(['api_token' => $token]);
						Session::put('kurir_id', $user->id);
						$data = Session::get('kurir_id');
						session()->save();
            return response()->json(['token' => $token, "Message"=>"Succesfully logged in","Kurir_Id"=> $data], 200);
        }

        return response()->json(['error' => 'Invalid credentials'], 401);
    }
	//{"token":"16|JEXDcJBNPGfE55Xe3saWoitEKxEjaHo3Ad8Abu1u","Message":"Succesfully logged in","Kurir_Id":1} jika  sukses loggin
	public function loginVerification(Request $request){
		  return response()->json(['error' => 'Credentials Needed'], 401);

	}
}
					/*
											$kurirs = Kurir::all();

						foreach ($kurirs as $kurir) {
								echo $kurir->name;
								echo $kurir->email;
						}
						*/