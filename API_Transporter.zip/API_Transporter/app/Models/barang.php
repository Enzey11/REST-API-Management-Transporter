<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Barang extends Model
{
		public $timestamps = false;
    use HasFactory;
		protected $table = "barang";
    protected $fillable = [
        'kode_barang',
        'nama_barang',
        'deskripsi',
        'stok_barang',
        'harga_barang',
    ];
}
