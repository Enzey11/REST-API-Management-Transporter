<?php 
namespace App\Models;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Laravel\Sanctum\HasApiTokens;
use Illuminate\Database\Eloquent\Factories\HasFactory;
class Kurir extends Authenticatable
{
		public $timestamps = false;
    use HasApiTokens;

    use HasFactory;

    protected $table = 'kurir';

    protected $fillable = [
        'name',
        'email',
        'password',
    ];

    protected $hidden = [
        'password',
        'remember_token',
    ];
}


?>