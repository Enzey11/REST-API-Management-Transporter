<?php
use App\Http\Controllers\AuthController;
use App\Http\Controllers\getDataMaster;
use App\Http\Controllers\LokasiController;
use App\Http\Controllers\BarangController;
use App\Http\Controllers\PengirimanController;
use App\Http\Controllers\KurirController;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/



		Route::post('login/auth', [AuthController::class, 'login']);

		Route::get('login', [AuthController::class, 'loginVerification'])->name('login');

	

		Route::post('dashboard/lokasi/add', [LokasiController::class, 'store']);
		Route::get('dashboard/lokasi/getall/', [LokasiController::class, 'index']);
		Route::get('dashboard/lokasi/get/{id}', [LokasiController::class, 'show']);
		Route::put('dashboard/lokasi/change/{id}', [LokasiController::class, 'update']);
		Route::delete('dashboard/lokasi/delete/{id}', [LokasiController::class, 'destroy']);

		//================ kurir ===========

		Route::post('dashboard/kurir/add', [KurirController::class, 'store']);
		Route::get('dashboard/kurir/getall/', [KurirController::class, 'index']);
		Route::get('dashboard/kurir/get/{id}', [KurirController::class, 'show']);
		Route::put('dashboard/kurir/change/{id}', [KurirController::class, 'update']);
		Route::delete('dashboard/kurir/delete/{id}', [KurirController::class, 'destroy']);

		// ===========  pengiriman ============

		Route::post('dashboard/Pengiriman/add', [PengirimanController::class, 'store']);
		Route::get('dashboard/Pengiriman/getall/', [PengirimanController::class, 'index']);
		Route::get('dashboard/Pengiriman/get/{id}', [PengirimanController::class, 'show']);
		Route::put('dashboard/Pengiriman/change/{id}', [PengirimanController::class, 'update']);
		Route::delete('dashboard/Pengiriman/delete/{id}', [PengirimanController::class, 'destroy']);

		Route::post('dashboard/Barang/add',           [BarangController::class, 'store']);
		Route::get('dashboard/Barang/getall/',     	  [BarangController::class, 'index']);
		Route::get('dashboard/Barang/get/{id}',    	  [BarangController::class, 'show']);
		Route::put('dashboard/Barang/change/{id}', 	  [BarangController::class, 'update']);
		Route::delete('dashboard/Barang/delete/{id}', [BarangController::class, 'destroy']);




